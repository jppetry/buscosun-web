# Prüfstand — feste Verifikationsroutine für buscosun Fusion (PS-0 … PS-4)

> Stand: 2026-10-05 (Plan, vor Diagnose; ergänzt um Vergleichsmodus, Rekonstruktion alter Versionen und Archiv-Punktliste). Auftrag Jan 05.10.: eine Testroutine für das Postprocessing buscosun Fusion,
> die jede neue Version (buscosun Fusion [n]) an realen Stationen nach immer denselben Kriterien bewertet und gegen die
> letzte und alle früheren Iterationen vergleicht. **Einmal bauen, danach je Version nur noch laufen lassen.**
> Konzept: Claude-Doc „buscosun Prüfstand – Verifikationsroutine für Fusion-Postprocessing“
> <https://claude.ai/code/artifact/c70f165b-12c5-469b-bbd8-7d6618a918da>, als Markdown-Abschrift in
> `audit/pruefstand-konzept.md` (Verweise „Konzept §n“ beziehen sich darauf; bei Widerspruch gilt dieser Plan).
> Kickoff: `prompt-pruefstand.md`.
> **Fünf Phasen, fünf Gates, ein Commit je Phase.** PS-0 schreibt keinen Code. Push, Änderungen in anderen Repos und
> Freigaben sind Jans Gate.

## 0. Kurzfassung für Jan

1. **Was gebaut wird:** fester, deterministischer Code unter `scripts/pruefstand/` und `src/pruefstand/`, ein
   eingefrorenes Prüfprotokoll P1, eine eigene Wahrheitstabelle W1 aus DWD, GeoSphere und MeteoSwiss, ein Modellregister
   mit Replay je Version und ein Claude-Code-Skill `/pruefe-fusion` (Anhang A).
2. **Was du danach je neuer Version tust:** `/pruefe-fusion 9` (Volltest auf der Entwicklungsmenge) und, wenn das gut
   aussieht, `/pruefe-fusion 9 abnahme` (Urteil gegen Champion und alle Vorgänger, Rangliste). Der freie Satz „teste die
   neue buscosun fusion 9 über unsere Prüfroutine“ löst denselben Skill aus. Der Skill rechnet nichts selbst: Er startet
   das Skript und fasst `scores.json` in festem Format zusammen.
3. **Einzige wiederkehrende Codearbeit:** Ändert eine neue Version die Schnittstelle der Engine (Eingaben, Ausgaben,
   Optionen), bricht ihr Adapter, und der Skill stoppt mit genauer Meldung. Ändert sich das Protokoll, entsteht P2 und
   alle Versionen werden neu bewertet, nie stillschweigend.
4. **Reihenfolge:** PS-0 Diagnose → deine Entscheidungen E-PS-1…11 → PS-1 Fundament → PS-2 Replay → PS-3 Statistik und
   Bericht → PS-4 Befehl. Die erste belastbare Abnahme ist ab G-PS3 möglich. Spur P hat heute gut drei Wochen; damit
   sind nur große Unterschiede nachweisbar.
5. **Korrektur am Konzept (betrifft E-PS-8):** Ein nächtlicher Schattenlauf ist unnötig. Das Archiv ist append-only und
   hält die Eingaben jedes Tages; der Replay rechnet eine Version jederzeit nachträglich auf allen Tagen nach ihrem
   Freeze. Dazu liegt `buscosun-hindcast` nur lokal (kein Git, laut Notizen rund 46 GB mit Cache). **Alles läuft lokal;
   GitHub Actions braucht der Prüfstand nicht.**
6. **Aufruf:** `npm run` schluckt `--`-Argumente (CLAUDE.md). Skill und Doku rufen deshalb direkt
   `node --experimental-strip-types --import ./scripts/lib/register-ts.mjs scripts/pruefstand/run.mjs …` auf.
7. **Eilpunkt Archiv (D-PS-2 zuerst):** Eine Station ist nur prüfbar, wenn das Archiv für ihren Ort die
   Vorhersage-Eingaben gesichert hat. Messwerte lassen sich jahrelang nachladen, Cube-Zellen nicht: `buscosun-data`
   löscht alte Läufe, die offenen Modellserver halten sie nur kurz. Speichert das Archiv den Cube nur an seiner
   Punktliste (wie der Hindcast), zählen neue Stationen erst ab dem Tag, an dem das Archiv sie mitschreibt. PS-0
   klärt das als Erstes und meldet es sofort; die Erweiterung der Punktliste (E-PS-11) ist ein eigener, eiliger Antrag
   in `buscosun-archiv`, unabhängig vom Bau des Prüfstands.
8. **Mehrere Versionen gegeneinander** (z. B. 5e, 6, 7, 8): Modus `vergleich` erstellt eine Rangliste auf der größten
   gemeinsamen sauberen Prüfmenge. Alte Versionen zählen nur, wenn Commit, Tabellen und lesbare Eingaben erhalten sind
   (D-PS-7); sonst stehen sie als „nicht rekonstruierbar“ im Register.

## 1. Ausgangslage (aus Projektnotizen, nicht am Code gelesen — jeden Anker in PS-0 prüfen)

| Baustein | Stand laut Notizen | Prüfen in |
|---|---|---|
| `buscosun-archiv` | `C:\dev\buscosun-archiv`, Git `jppetry/buscosun-archiv`; Cron täglich 23:10 UTC, ein Slot `<YYYY-MM-DD>/<HHMM>.json.gz` (Kollision als `-r1`), append-only, Schema 3, ab 14.09.2026; Leser `lib/punktarchiv.mjs`; Inhalt `cube.t1/t2/t3`, `stations` (MOSMIX-L), `nowcast`, `hmodel`, `plan`, `live` (mu/q10/q50/q90), `truth.byPoint`, `stats`. **Unbekannt:** ob `cube` je Punkt oder als Gitter gespeichert ist, wie viele Punkte die Liste hat, ob Ankerwerte zur Ausgabezeit im Slot liegen; Punkte auch außerhalb von DACH (NL, DK) | D-PS-2, D-PS-3 |
| Audit-Befunde Archiv (Sept. 2026) | Bergstationen mit DEM- statt Stationshöhe; Höhenreferenzen `plan`/`live`/`points.elev` uneinheitlich; `id` ≠ `wmo` bei 17 AT-Punkten; 23‑UTC-Lücke DE/AT in der Wahrheit; leere Wahrheitsgrößen je Netz; `tsMs` null, `ageH` 0; Fusion teils `weights: equal` / `provenance: fallback` | D-PS-3, D-PS-5 |
| `buscosun-hindcast` | `C:\dev\buscosun-hindcast`, kein Git; `slots/` (t1 ab 25.05.2023, t2/t3 ab 01.04.2024), `truth/` (24.05.2023–21.09.2026, dazu `stations.json`), `cells/`, `shadow/`, `verify/`, `index.json`; Provenienz „Lauf“ (ab 17.06.2026), „Tag 0“, „dyn“ | D-PS-4 |
| Fusion-Engine | `src/pointForecast/fusion/*` (`fuse.ts`, `dist.ts` mit `quantileOf`), Tabellen `fusion.client.json`, `precip-cal.client.json`, Cube-Leser `src/point/cubeFormat.ts`, `read-point.mjs` | D-PS-5 |
| Vorhandene Prüfungen | `verify:fusion-fit`, `verify:point-client`, `verify:point-data`; Scorer der Phasen FL/FV/AX (Archiv, Niederschlag „nass“ = Radar-Analyse ≥ 0,1 mm/h) | D-PS-1 |
| Offene Einheit | `precip` im Cube: Rate oder Intervallsumme (offen seit D-NP0-9) | D-PS-6 |

## 2. Ziel und Abgrenzung

- **Ziel:** Eine Routine, die jede registrierte Fusion-Version auf identischen Prüffällen per Replay rechnet, an
  zurückgehaltenen Stationen gegen eine eingefrorene Wahrheit bewertet und ein Urteil nach festen Gates ausgibt.
  Gleiche Hashes (Protokoll, Wahrheit, Fälle, Modell) ⇒ gleiche Zahlen.
- **Nicht Teil:** Änderungen an buscosun Fusion (Motor, Tabellen, Optionen, Fit-Pipeline) — nur aufrufen; jede
  Oberfläche in buscosun-web; Feldverifikation (FSS gegen Radar); Bewertung der Schneefallgrenze (keine Bodenwahrheit);
  Änderungen in `buscosun-archiv` oder `buscosun-data` (E-PS-6 und E-PS-11 sind eigene Anträge); Archivpunkte außerhalb
  von DACH (NL, DK) gehören nicht zu P1.
- **Funktionserhalt:** Kein bestehender Job, Verifier oder Build ändert sein Verhalten. Der Prüfstand liest Archiv,
  Hindcast und Daten-Repo nur.

## 3. Was P1 einfriert (Kurzfassung Konzept §2–§11; mit * markierte Werte entscheidet Jan nach PS-0)

| Baustein | Festlegung P1 | Konzept |
|---|---|---|
| Prüfnetz | Stationen DE/AT/CH mit Rolle A (Anker) oder B (zurückgehalten: nie im Fit, im Replay aus den Ankern maskiert); B geschichtet nach Land × Geländeklasse × Höhenstufe, fester Seed, Anteil* (E-PS-2); B-Paare Tal/Berg unter 15 km | §4 |
| Zielort | Länge, Breite und gemessene Stationshöhe aus eingefrorenen Metadaten, nie DEM-Höhe; Verlegung ⇒ neue Station | §4 |
| Wahrheit W1 | Nur amtliche Bodenmessnetze: DWD CDC (rund 200 hauptamtliche + knapp 300 weitere automatische Wetterstationen, knapp 500 automatische Niederschlagsstationen; 10 min / Stunde, Qualitätsniveau QN), GeoSphere `klima-v2-10min` / `-1h` (rund 260 Stationen), MeteoSwiss A1 (rund 160 SwissMetNet) und A2 (rund 100 Niederschlagsstationen). Reine Niederschlagsstationen nur für Niederschlag. Nicht Wahrheit: Radar (nur getrennte Zweitwahrheit Niederschlag), MOSMIX (Referenz), private Netze, SWIS-Straßenwetter, Ländernetze. QC nur aus Messreihe, Nachbarn, Quellflags, nie aus einer Vorhersage; Reifezeit 7 Tage für die Abnahme; Stand W1 mit Hash | §3, §4 |
| Anker im Replay | Ankerwerte so, wie sie zur Ausgabezeit vorlagen (Echtzeit), nicht nachträglich korrigierte Archivwerte; fehlen sie im Slot, wird das je Fall gekennzeichnet | §6 |
| Prüffall | (Ausgabezeit, Station, Gültigkeitszeit, Größe); Vorlauf ab Ausgabezeit, nicht ab Modellstart | §5 |
| Raster | stündlich bis 48 h, dreistündlich bis 120 h, sechsstündlich bis 336 h | §5 |
| Vorlauf-Fenster | 0–6, 6–24, 24–48, 48–120, 120–240, 240–336 h; Nahtbänder 48/51, 120/126, 180 h | §5 |
| Kerngrößen | T2m, Taupunkt, Wind 10 m, Böe, Niederschlag (Menge und Ereignis); Nebengrößen laut Konzept §5 | §5 |
| Hauptmaß | CRPS_Q = 2/K · Σ QS_τk über den Quantilsatz* (E-PS-1); für einen Einzelwert gleich MAE | §7 |
| Weitere Maße | Bias, MAE, RMSE; Abdeckung q10–q90, PIT, Spread-Skill; Schärfe; Brier mit Zerlegung, CORP-Diagramm; twCRPS, SEDI; RPS; Winkelfehler | §7 |
| Referenzen | Klimatologie lokal (Station × Kalendertag × Stunde, nur Trainingsjahre), Persistenz (nur A), Rohquellen, Rohquellen + 0,65 K/100 m, MOSMIX-L, naive Fusion, alle Vorgänger | §8 |
| Spuren | P: Archivtage nach dem Freeze der Version; R: Tresor im Hindcast* (E-PS-3), Sperre auf Ausgabe- **und** Gültigkeitszeit, Abstand aus der gemessenen Autokorrelation | §6 |
| Statistik | Tagesdifferenzen je Zelle; gepaarter t-Test mit AR(2)-Inflation, Block-Bootstrap für kleine n; Benjamini-Hochberg über Kernzellen; Nachweisgrenze je Zelle | §10 |
| Indizes | Fortschrittsindex (gegen Champion, entscheidet), Güteindex (gegen Klimatologie, Rangliste); Gewichte* (E-PS-4) | §11 |
| Gates | G1 Fortschritt · G2 kein Rückschritt (Toleranz δ*, E-PS-5) · G3 Kalibrierung (Binomialband aus n_eff) · G4 Technik (Determinismus, Physik, Vollständigkeit, Punktabfrage < 300 ms, Leck-Prüfung) | §11 |

P1 liegt als JSON unter `scripts/pruefstand/protokoll/p1/` (versioniert, mit Hash). Jede Änderung erzeugt P2; Zahlen
aus P1 und P2 werden nie verglichen.

## 4. PS-0 — Diagnose (kein Code außer Wegwerf-Proben im Scratch-Ordner; Ergebnis in §14)

| # | Frage | Wie |
|---|---|---|
| D-PS-1 | Was ist wiederverwendbar? Scorer der Phasen FL/FV/AX, `verify:fusion-fit`, Hindcast `verify/` und `shadow/`: Maße, Leser, Wahrheitsabgleich, Zeitkonventionen | Code-Suche; je Fund Pfad:Zeile und Urteil „übernehmen / anpassen / ersetzen“ |
| D-PS-2 | **Zuerst beantworten und sofort an Jan melden.** (a) Liegt `cube.t1/t2/t3` je Punkt (`byPoint`, welche Zellen je Punkt) oder als Gitter vor? (b) Wie viele Punkte hat die Liste, und wie viele der Messnetz-Stationen DE/AT/CH sind in **allen drei Stufen** durch gesicherte Zellen abgedeckt? (c) Liegen die Ankerwerte zur Ausgabezeit im Slot? (d) Bytes je Punkt und Slot (für E-PS-11). Danach Inventar: Tage, Slots, Kollisionen; welche Eingaben je Slot vollständig sind; ob `live` für alle Punkte und Vorläufe gefüllt ist; Rundung der `live`-Spalten | `lib/punktarchiv.mjs` über alle Slots, Tabelle je Tag; Stationslisten der drei Netze |
| D-PS-3 | Wahrheit: `truth.byPoint` und Hindcast-`truth/` gegen die Originalquellen an einer Stichprobe (≥ 3 Tage × 20 Stationen je Netz); Größen je Netz; Zeitstempel (UTC, Intervallende); Stationsmetadaten (Höhe, Windmesshöhe, Verlegungen) | Abruf der Originaldateien in einen Scratch-Ordner |
| D-PS-4 | Hindcast: Tage je Provenienz und Stufe; gleiche Struktur wie Archiv-Slots oder eigener Leser nötig; welche Tage die heutigen Fits (Stationswert, Lernstufe, `precip-cal`) gesehen haben | `index.json`, Fit-Skripte und ihre Eingaben |
| D-PS-5 | Replay: Lässt sich Fusion 8 je (Slot, Punkt) ohne Browser aufrufen? Einstieg, Eingaben, Optionen; Determinismus (zwei Läufe, Hash); lassen sich B-Stationen aus den Ankern nehmen, **ohne** den Motor zu ändern; liefert `dist.ts` 19 Quantile | Probe an 3 Slots × 10 Punkten gegen `live`. Muss der Motor geändert werden: STOPP |
| D-PS-6 | Einheiten und Definitionen je Größe in Cube, `live`, MOSMIX und Wahrheit: `precip` Rate oder Summe, Böen-Intervall, Momentanwert oder Mittel, Bewölkung | Code und Stichprobe |
| D-PS-7 | Versionen 5e, 6, 7, 8: je Version (a) Commit oder Tag; (b) liegen die gefitteten Tabellen (`fusion.client.json`, `precip-cal.client.json`, Stationswert-Tabelle) an diesem Commit im Web-Repo (`git show <commit>:<pfad>`) oder lagen sie nur in `buscosun-data` (dann vermutlich verloren: Löschen und Force-Push der Kartenlinie)? (c) holt die Engine zur Laufzeit etwas live nach (BrightSky, GeoSphere, Stationen)? (d) liest sie Archiv-Slots in Schema 3 oder braucht der Adapter einen Umsetzer? (e) zwei Läufe byte-gleich? (f) gibt es gespeicherte Ausgaben dieser Version für eine Treue-Probe (alte Verify-Berichte, `buscosun-hindcast/shadow/`)? (g) Freeze und Fit-Fenster belegbar? Urteil je Version: rekonstruierbar / teilweise / nicht | `git worktree` außerhalb des Repos, `npm ci`, Probe an 1 Slot × 3 Punkten |
| D-PS-8 | Autokorrelation der Tagesdifferenzen (Fusion 8 `live` gegen MOSMIX-L an A-Stationen, Archiv): AR(2)-Faktor k je Größe × Fenster, heutige Nachweisgrenze, Tresor-Abstand | Skript im Scratch, Ergebnis als Tabelle |
| D-PS-9 | Stationspool: Anzahl je Land × Geländeklasse × Höhenstufe; Abdeckung der Schichten bei 15/25/35 % B; Liste der Tal-/Berg-Paare unter 15 km | Metadaten + DEM |
| D-PS-10 | Laufzeit und Speicher: Replay je Slot × Version lokal; Größe der Fälle und Konserven je Tag; Speicher je Archiv-Slot (für E-PS-6) | Messung |
| D-PS-11 | Abhängigkeiten: DWD CDC liefert ZIP. Reicht ein eigener ZIP-Leser mit `node:zlib` (`inflateRawSync`), oder braucht es eine Abhängigkeit? | Probe an einer CDC-Datei |

**Gate G-PS0:** §14 gefüllt, Anker-Korrekturen zu §1 benannt, Entscheidungsvorlage E-PS-1…11 mit Messwerten. Jan
entscheidet; vorher keine Zeile Code im Repo.

## 5. PS-1 — Fundament

| Schritt | Inhalt |
|---|---|
| PS-1-1 Protokoll | `scripts/pruefstand/protokoll/p1/*.json` (Prüfnetz mit Rollen, Zielgrößen-Katalog, Fenster, Quantilsatz, Schwellen, Index-Gewichte, Gates, Tresor-Maske `tresor.json`) und `src/pruefstand/protokoll.ts` (Lader, Prüfer, Hash; rein) |
| PS-1-2 Wahrheit W1 | `scripts/pruefstand/wahrheit/`: Abruf je Netz, QC nach Konzept §4 (formal, zeitlich, räumlich, Quellflags, Repräsentanz), jeder verworfene Wert mit Grund protokolliert, Reifezeit-Kennzeichen; Ablage spaltenweise unter `C:\dev\buscosun-pruefstand\wahrheit\W1\` mit Manifest und Hash |
| PS-1-3 Prüffall-Bauer | Fälle aus Archiv (Spur P) und Hindcast (Spur R, je Provenienz getrennt) als Spaltenblöcke (`Float32Array` je Größe × Vorlauf) mit Verweis auf die Eingaben; Masken für B-Stationen und Tresor; Ablage `…\faelle\<spur>\<tag>.bin` mit Hash |
| PS-1-4 Maß-Kern | `src/pruefstand/metrics.ts` (rein): QS, CRPS_Q, Brier mit Zerlegung, Abdeckung, PIT, Spread-Skill, twCRPS, RPS, SEDI, Winkelfehler, Tagesaggregation, Skill als Verhältnis der Summen |
| PS-1-5 Sollwerte | Sollwerte aller Maße einmalig offline mit dem Python-Paket `scores` (Bureau of Meteorology) erzeugen und als JSON-Fixtures einchecken (`scripts/pruefstand/fixtures/`); zur Laufzeit kein Python |
| PS-1-6 Verifier | `scripts/verify-pruefstand.mjs` + `npm run verify:pruefstand` (netzfrei): Protokoll-Rundlauf mit Negativkontrolle, Maße gegen Sollwerte (Abweichung < 1e‑9), QC an synthetischen Reihen, Fall-Bau an einem Archiv-Fixture, Byte-Gleichheit bei Wiederholung |

**Gate G-PS1**

| Frage | Beleg |
|---|---|
| Maße | alle gegen `scores`-Sollwerte grün |
| Wahrheit | Rundlauf W1 gegen die Originale (Stichprobe aus D-PS-3) ohne unerklärte Abweichung; Verwerfungsquote je Netz benannt |
| Protokoll | P1 lädt, Hash stabil; ein manipuliertes P1 wird abgelehnt |
| Verifier | `typecheck`, `verify:pruefstand`, `build` |

## 6. PS-2 — Register und Replay

| Schritt | Inhalt |
|---|---|
| PS-2-1 Register | `scripts/pruefstand/register/<id>.json` je Version: Commit, Tabellen-Hashes, Optionen, Freeze-Datum, Fit-Fenster, Tresor-Hash, Adapter-Version, Status (Kandidat / Champion / abgelehnt / historisch). `run.mjs --registriere <id>` füllt Commit und Hashes aus Git; was sich nicht belegen lässt (Freeze, Fit-Fenster), fragt der Skill Jan einmal |
| PS-2-2 Adapter-Vertrag | `src/pruefstand/adapter.ts`: `predict(fall) → Quantilblock` im Quantilsatz von P1 und in den Einheiten des Zielgrößen-Katalogs; Vertragstest mit Negativkontrollen (falsche Einheit, nicht monotone Quantile ⇒ Abbruch mit Meldung) |
| PS-2-3 Adapter | Adapter für Fusion 8 (Champion); Referenzen als Pseudo-Versionen: Klimatologie (aus W1, nur Trainingsjahre), Persistenz, Rohquellen je Modell, Rohquellen + 0,65 K/100 m, MOSMIX-L, naive Fusion |
| PS-2-4 Runner | `git worktree` je Version unter `C:\dev\buscosun-pruefstand\worktrees\<id>`; Tage auf `worker_threads`; B-Stationen aus den Anker-Eingaben maskiert; Tresor und Spur P öffnet nur der Modus `abnahme`, jede Öffnung in `scripts/pruefstand/register/zugriffe.log` |
| PS-2-5 Konserven | Vorhersagen adressiert nach (Modell-Hash, Fall-Hash, Protokoll-Hash) unter `…\konserven\`; inkrementell: neuer Archivtag ⇒ nur dieser Tag wird gerechnet |
| PS-2-6 Replay-Treue | Fusion 8 ohne Maske auf allen Archiv-Slots gegen die gespeicherten `live`-Werte; Abweichungsstatistik je Größe × Vorlauf |
| PS-2-7 Champion unter Tresor | Nur wenn der Fit von Fusion 8 ohne Motor-Änderung mit Tresor-Maske wiederholbar ist; sonst Status „R kontaminiert“ (E-PS-9) |
| PS-2-8 Altversionen | Für jede nach D-PS-7 rekonstruierbare Version (5e, 6, 7) Register-Eintrag mit Status „historisch“ und Adapter (ein Adapter je Schnittstellen-Generation, nicht je Version). Treue-Probe gegen gespeicherte Ausgaben, wo vorhanden; sonst Kennzeichen „Treue nicht prüfbar“ im Register und im Bericht. Nicht rekonstruierbare Versionen: Status „nicht rekonstruierbar“, nie mit Ersatz-Tabellen oder Refit nachgestellt |

**Gate G-PS2 (kritisch):** Replay-Treue gleich bis auf die Rundung der `live`-Spalten (aus D-PS-2); zwei Läufe
byte-gleich; Vertragstests grün; `verify:pruefstand` erweitert. Hält G-PS2 nicht, sind alle späteren Vergleiche
wertlos: STOPP, PS-3 beginnt nicht.

## 7. PS-3 — Statistik, Gates, Bericht

| Schritt | Inhalt |
|---|---|
| PS-3-1 Statistik | `src/pruefstand/stats.ts`: Tagesdifferenzen je Zelle, AR(2)-Inflation, Block-Bootstrap (Blocklänge aus der Autokorrelation), Benjamini-Hochberg über Kernzellen, Nachweisgrenze |
| PS-3-2 Gates | G1–G4 und Überanpassungs-Warnung nach Konzept §11; Urteil Champion / Kandidat / abgelehnt |
| PS-3-3 Sonderprüfungen | Höhenpaare (ΔT, ΔTd, getrennt nach Inversion zur Ausgabezeit), Nahtsprünge, Sprunghaftigkeit (nur bei mehr als einem Slot je Tag), Stundeninterpolation t2/t3 |
| PS-3-4 Bericht | `audit/pruefstand/berichte/<id>/<datum>/bericht.html` (eine Datei, ohne externe Abhängigkeiten) und `scores.json` (alle Zellen und Tagesreihen); Gliederung nach Konzept §13; erste Zeile = Urteil in einem Satz; Quellenvermerke DWD, GeoSphere, „Source: MeteoSwiss“ |
| PS-3-5 Rangliste | `audit/pruefstand/rangliste.json`; nur der Modus `abnahme` schreibt |
| PS-3-6 Vergleichsmodus | `--modus vergleich --versionen fusion-5e,fusion-6,…`: Güteindex und Scorecards aller genannten Versionen auf der größten gemeinsamen sauberen Prüfmenge (Spur P: Tage nach dem jüngsten Freeze der Auswahl; Spur R nur für nicht kontaminierte Versionen), Zahl der Tage und Fälle im Kopf, paarweise Differenzen mit Konfidenzintervall. Entscheidet nichts und schreibt keine Rangliste; Bericht unter `audit/pruefstand/vergleiche/<datum>/` |
| PS-3-7 Selbstprüfung | A/A-Test (Champion gegen einen Bootstrap-Fit von sich selbst, viele Wiederholungen) legt Testverfahren und Mindesttage fest; Negativkontrollen nach Konzept §14 |

**Gate G-PS3:** A/A-Test trifft die nominale Irrtumsrate (Spanne aus den Wiederholungen benannt); alle
Negativkontrollen schlagen an; Bericht und `scores.json` byte-gleich bei Wiederholung.

## 8. PS-4 — Befehl und Doku

| Schritt | Inhalt |
|---|---|
| PS-4-1 Einstieg | `scripts/pruefstand/run.mjs --kandidat <id> --modus schnell\|voll\|abnahme`, `--modus vergleich --versionen <id,id,…>`, `--modus status` und `--registriere <id>`; Exit-Code ≠ 0 bei Vertragsbruch, G4-Verstoß oder fehlgeschlagener Selbstprüfung |
| PS-4-2 Skill | `.claude/skills/pruefe-fusion/SKILL.md` nach Anhang A |
| PS-4-3 Doku | CLAUDE.md-Dokumentenkarte; Abschnitt in `MANUELLE-SCHRITTE.md`; `audit/pruefstand/README.md` (Bedienung in zehn Zeilen) |
| PS-4-4 Erster Lauf | `/pruefe-fusion 8 abnahme` als Selbsttest: Champion gegen sich selbst ⇒ „kein Fortschritt“, G2–G4 grün, Rangliste mit Fusion 8 und allen Referenzen |

**Gate G-PS4:** Selbsttest grün; ein bewusst verschlechterter Kandidat (Fusion 8 mit verbreiterten Bändern) wird über
den Skill abgelehnt.

## 9. Entscheidungen (Jan) — PS-0 legt sie mit Messwerten vor und wartet

| # | Frage | Optionen | Empfehlung | Jans Entscheidung |
|---|---|---|---|---|
| E-PS-1 | Quantilsatz | 3 Stufen q10/q50/q90 (wie `live`) · 19 Stufen 5–95 % per Replay | 19 für Versionen mit `dist.ts`, 3 zusätzlich als gemeinsamer Nenner; nach D-PS-5 |  |
| E-PS-2 | Anteil Prüfstationen B | 15 / 25 / 35 % | 25 %, wenn D-PS-9 jede Schicht abdeckt |  |
| E-PS-3 | Tresor im Hindcast | jede 4. Woche · jede 5. Woche · ein ganzes Jahr | jede 4. Woche über alle Monate, Abstand aus D-PS-8 |  |
| E-PS-4 | Index-Gewichte | gleich · nach Nutzung · kurze Vorläufe betont | gleich, bis Nutzungsdaten vorliegen |  |
| E-PS-5 | Toleranz δ in G2 | 0 · 1 % · Nachweisgrenze | 0 (G2 zählt nur mehrfachkorrigiert signifikante Zellen) |  |
| E-PS-6 | Archiv-Cron mit 4 Slots je Tag | ja · nein | ja, als eigener Antrag in `buscosun-archiv`; Speicher aus D-PS-10 |  |
| E-PS-7 | Ort | Code in `buscosun-web`, Daten in `C:\dev\buscosun-pruefstand\` · eigenes Repo | Code in `buscosun-web`, große Daten lokal (wie der Hindcast), Berichte und Rangliste versioniert unter `audit/pruefstand/` |  |
| E-PS-8 | Wo läuft es? | lokal · Actions | **lokal** (geändert gegenüber dem Konzept, s. §0.5) |  |
| E-PS-9 | Bestandsversionen unter Tresor nachfitten | ja · nein | ja für den Champion, wenn ohne Motor-Änderung möglich; sonst „R kontaminiert“ |  |
| E-PS-10 | ZIP für DWD CDC | eigener Leser mit `node:zlib` · Abhängigkeit | eigener Leser, wenn D-PS-11 ihn trägt |  |
| E-PS-11 | Archiv-Punktliste erweitern (**eilig**, nur falls D-PS-2 „je Punkt“ zeigt) | alle nutzbaren Stationen DE/AT/CH · nur die Prüfstationen B · nicht | alle nutzbaren Stationen, sofort, als eigener Antrag in `buscosun-archiv`; Speicher aus D-PS-2 (d) vorher hochrechnen |  |

## 10. Harte Grenzen (STOPP & FRAGEN)

- Keine Änderung an buscosun Fusion (`src/pointForecast/**` inkl. `fusion/*`, Tabellen, Optionen, `FUSION*`-Schalter,
  Fit-Pipeline) — nur aufrufen. Braucht der Replay oder das Maskieren eine Änderung am Motor: STOPP.
- `buscosun-archiv`, `buscosun-hindcast` und `C:\dev\buscosun-data` nur lesen; `git pull --ff-only` im Archiv-Klon ist
  erlaubt. Proben in einem Scratch-Ordner.
- Kein Push, kein Commit in andere Repos, kein Workflow in Archiv- oder Daten-Repo.
- Keine neue Abhängigkeit ohne Rückfrage (E-PS-10).
- Tresor und Spur P nur im Modus `abnahme` öffnen; jede Öffnung protokollieren.
- Protokoll-Werte ändern sich nur über P2 mit Jans Zustimmung; nachträgliches Verschieben einer Schwelle ist verboten.
- Wahrheit nie anhand einer Vorhersage filtern.
- Keine Konstante ohne Herleitung: jede Zahl in P1 ist gemessen oder als Jans Entscheidung markiert.

## 11. Jans Gates

- **Je Phase:** Durchsicht, Commit (Scope `pruefstand`), Push `buscosun-web`. PS-0 committet nur diese MD-Datei.
- **G-PS0:** Entscheidungen E-PS-1…11 in §9 eintragen (Spalte „Jans Entscheidung“).
- **E-PS-6:** eigener Antrag und Push in `buscosun-archiv`.
- **PS-4:** Der Skill ist nach dem Commit sofort aktiv (Projekt-Skill im Repo).

## 12. Bedienung nach dem Bau — je neue Version

1. Neue Fusion-Version committen (Code und Tabellen).
2. `/pruefe-fusion 9` oder „teste die neue buscosun fusion 9 über unsere Prüfroutine“: Register-Eintrag, Volltest auf
   der Entwicklungsmenge, Kurzurteil. Beliebig oft wiederholbar, ohne den Tresor zu verbrauchen.
3. Sieht das gut aus: `/pruefe-fusion 9 abnahme`: Selbstprüfung, Abnahme gegen Champion und alle Vorgänger, Bericht,
   Rangliste, Urteil Champion / Kandidat / abgelehnt.
4. Bei „Kandidat“ (noch nicht nachweisbar): später erneut abnehmen; der Replay rechnet die neuen Archivtage nach.
5. Bei „Champion“: Status im Register setzt Jan; die Liveschaltung von Fusion 9 bleibt ein eigener Schritt.

## 13. V-Katalog (Start)

- **V-PS-1** Die Fit-Pipeline schreibt Fit-Fenster und Tresor-Hash in die Tabellen-Metadaten. Mehrwert: Register und
  Leck-Prüfung vollautomatisch. Braucht eine Änderung an Fusion, also eigener Antrag.
- **V-PS-2** Archiv mit 4 Slots je Tag (E-PS-6). Mehrwert: Vorlauf und Tageszeit entkoppelt, Sprunghaftigkeit messbar.
- **V-PS-3** Das Archiv schreibt jede neue Quelle ab dem Tag mit, an dem ihre Integration beginnt (Konzept §16).
- **V-PS-4** Spur R aus Originalquellen statt Open-Meteo-Nachbau (Lizenz bei späterer Monetarisierung).
- **V-PS-5** Konzept-Doc nachziehen: kein Actions-Schattenlauf, alles lokal (§0.5).
- **V-PS-6** Das Archiv speichert die Ankerwerte zur Ausgabezeit mit (falls D-PS-2 (c) „nein“ ergibt). Mehrwert: Replay
  ohne nachträglich korrigierte Messwerte, also ohne geschönte Anker.

## 14. Diagnose-Ergebnis und Umsetzung (füllt die Phase)

*(leer — D-PS-1…11 mit Belegen, Anker-Korrekturen zu §1, E-PS-1…11 mit Jans Antworten, Umsetzung PS-1…PS-4,
Gate-Tabellen ausgefüllt, neue V-Einträge)*

## Anhang A — `.claude/skills/pruefe-fusion/SKILL.md` (Lieferobjekt PS-4-2)

```markdown
---
name: pruefe-fusion
description: Prüft eine Version von buscosun Fusion mit dem festen Prüfstand (Protokoll P1) an realen Stationen gegen den Champion und alle früheren Versionen. Immer verwenden, wenn Jan eine Fusion-Version testen, prüfen, bewerten, vergleichen oder abnehmen will, z. B. "teste die neue buscosun fusion 9 über unsere Prüfroutine", "/pruefe-fusion 9", "ist fusion 9 besser als 8?".
---

# Prüfstand ausführen

Argumente: $ARGUMENTS — Version (z. B. `9` oder `fusion-9`), optional `abnahme` oder `schnell`;
oder mehrere Versionen mit `vergleich` (z. B. `5e 6 7 8 vergleich`).
Register: !`node --experimental-strip-types --import ./scripts/lib/register-ts.mjs scripts/pruefstand/run.mjs --modus status`

Du bedienst eine feste Routine. Du rechnest keine Maße selbst, änderst kein Protokoll, keine Schwelle, keine Tabelle
und keinen Code unter `src/pointForecast/`. Zahlen kommen nur aus `scores.json`.

## Ablauf
1. Version auf `fusion-<n>` normalisieren. Archiv-Klon `C:\dev\buscosun-archiv` mit `git pull --ff-only` aktualisieren.
2. Register prüfen (`scripts/pruefstand/register/fusion-<n>.json`). Fehlt der Eintrag:
   `run.mjs --registriere fusion-<n>`. Fehlen Freeze-Datum oder Fit-Fenster: Jan fragen, nichts raten.
3. Modus: ohne Zusatz `voll`; `schnell` nur auf ausdrücklichen Wunsch; `abnahme` nur, wenn Jan das Wort nennt;
   mehrere Versionen nur mit `vergleich` (`--modus vergleich --versionen fusion-5e,fusion-6,…`); der Vergleich entscheidet nichts.
   Die Abnahme öffnet Tresor und Spur P und wird protokolliert. Nie von selbst zur Abnahme wechseln.
4. Ausführen: `node --experimental-strip-types --import ./scripts/lib/register-ts.mjs scripts/pruefstand/run.mjs --kandidat fusion-<n> --modus <modus>`
5. Exit-Code ≠ 0: STOPP. Meldung wörtlich wiedergeben (Adapter-Vertrag, G4, Selbstprüfung, fehlende Wahrheit) und
   sagen, was zu tun ist. Keinen Workaround bauen.
6. Antwort im festen Format, Link auf den Bericht.

## Antwortformat
**Fusion <n> — <Champion | Kandidat | abgelehnt | Volltest>** (Protokoll P1, Wahrheit W<x>, Spur <P/R>, <Tage> Tage)
- Fortschrittsindex gegen <Champion>: <±x,x %> (95 %: <a … b>), Nachweisgrenze <y %>
- Gates: G1 <…> · G2 <…> · G3 <…> · G4 <…>
- Drei beste und drei schlechteste Kernzellen (Größe × Fenster × Land, Änderung, Signifikanz)
- Produktaussage: in <k> von <m> Kernzellen besser als jede Einzelquelle
- Warnungen: Überanpassung, unreife Wahrheit, Spur R kontaminiert
- Bericht: <Pfad>
Ist ein Unterschied nicht nachweisbar, das genau so sagen, nicht „besser“ oder „schlechter“.
```
